package ma.ensaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootRestSecurityBookReservation1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootRestSecurityBookReservation1Application.class, args);
	}

}