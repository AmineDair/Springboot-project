package ma.ensaf.service;

import java.util.List;

import ma.ensaf.model.Book;

public interface IBookService {
   
	public List<Book> findAllBook();
	public Book findById(int id);
	public void save(Book book);
	public void deleteById(int id);
	
}
