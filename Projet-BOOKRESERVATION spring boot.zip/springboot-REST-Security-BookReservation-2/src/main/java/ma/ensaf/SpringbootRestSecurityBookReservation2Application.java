package ma.ensaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootRestSecurityBookReservation2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootRestSecurityBookReservation2Application.class, args);
	}

}
